import "../styles/styles.css";
import App from "./pages/app";

document.addEventListener("DOMContentLoaded", async () => {
  const app = new App({
    content: document.querySelector("#main-content"),
    drawerButton: document.querySelector("#drawer-button"),
    navigationDrawer: document.querySelector("#navigation-drawer"),
  });
  await app._renderPage();

  // Tambahkan kode untuk handle skip to content
  const mainContent = document.querySelector('#main-content');
  const skipLink = document.querySelector('.skip-link');

  skipLink.addEventListener('click', function (event) {
    event.preventDefault();
    skipLink.blur();
    
    mainContent.setAttribute('tabindex', '-1');
    mainContent.focus();
    mainContent.scrollIntoView();
    
    // Hapus tabindex setelah fokus untuk menghindari outline yang tidak diinginkan
    setTimeout(() => {
      mainContent.removeAttribute('tabindex');
    }, 1000);
  });

  window.addEventListener("hashchange", async () => {
    await app._renderPage();
  });
});
